
# Fox Valley Tactical Dashboard v3 – Zacks Tactical Edition

**Deployment Steps**
1. Upload `fox_valley_dashboard.py` and `requirements.txt` to your GitHub repo.
2. Commit directly to the `main` branch.
3. In Streamlit Cloud:
   - Open your app.
   - Click ⋮ → Clear cache and Reboot.
4. In the sidebar of your dashboard:
   - Upload the three Zacks CSVs (Growth 1, Growth 2, Defensive Dividend).

**Features**
- Portfolio overview with SPAXX (Money Market) cash sleeve.
- Zacks Rank color coding:
  - 🟩 Rank 1 = Strong Buy
  - 🟨 Rank 2 = Buy
  - 🟧 Rank 3-5 = Monitor/Trim
- Dark-mode interface optimized for six-monitor setup.
- Sunday 07:00 CST automation hook for tactical summaries.

