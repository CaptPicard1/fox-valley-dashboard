# 🧭 Fox Valley Dashboard

Fox Valley Technical Console — Interactive investment dashboard.

## Quick Start
1. Upload these files to your GitHub repository `fox-valley-dashboard`
2. Commit directly to `main`
3. Visit Streamlit:
   https://fox-valley-dashboard-xkfn8xrsdjevuhod8ufvfb.streamlit.app
4. Reboot the app from the ⋮ menu.

✅ Displays:
- Total Account Value: $162,167.42
- Cash Available: $27,694.93
- Interactive portfolio charts & metrics

Next Automation Cycle: Sunday, Nov 2, 2025 – 7:00am CST
